export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyDfp6sUDwDqfRyJiiZvs4VYwgh7P10zp5Y",
    authDomain: "crudfirebase-f654a.firebaseapp.com",
    databaseURL: "https://crudfirebase-f654a.firebaseio.com",
    projectId: "crudfirebase-f654a",
    storageBucket: "crudfirebase-f654a.appspot.com",
    messagingSenderId: "52526050316",
    //appId: "1:52526050316:web:acd6b65daa0c59d8"
  };