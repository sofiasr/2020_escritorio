export interface Tip {
    id: number;
    descripcion: string;
}