export interface ComenUsu{
    comentario
    imagen
}