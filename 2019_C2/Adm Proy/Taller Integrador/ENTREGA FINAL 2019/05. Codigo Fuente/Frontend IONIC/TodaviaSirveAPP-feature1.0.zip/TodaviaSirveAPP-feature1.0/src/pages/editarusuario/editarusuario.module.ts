import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditarusuarioPage } from './editarusuario';

@NgModule({
  declarations: [
    EditarusuarioPage,
  ],
  imports: [
    IonicPageModule.forChild(EditarusuarioPage),
  ],
})
export class EditarusuarioPageModule {}
