import { NgModule } from '@angular/core';
import { AvatarUserComponent } from './avatar-user/avatar-user';
@NgModule({
	declarations: [AvatarUserComponent],
	imports: [],
	exports: [AvatarUserComponent]
})
export class ComponentsModule {}
