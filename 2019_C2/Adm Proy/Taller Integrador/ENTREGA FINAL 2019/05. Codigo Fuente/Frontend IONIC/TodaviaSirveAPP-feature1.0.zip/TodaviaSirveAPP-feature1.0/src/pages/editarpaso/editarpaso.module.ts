import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditarpasoPage } from './editarpaso';

@NgModule({
  declarations: [
    EditarpasoPage,
  ],
  imports: [
    IonicPageModule.forChild(EditarpasoPage),
  ],
})
export class EditarpasoPageModule {}
