import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PasosPage } from './pasos';

@NgModule({
  declarations: [
    PasosPage,
  ],
  imports: [
    IonicPageModule.forChild(PasosPage),
  ],
})
export class PasosPageModule {}
