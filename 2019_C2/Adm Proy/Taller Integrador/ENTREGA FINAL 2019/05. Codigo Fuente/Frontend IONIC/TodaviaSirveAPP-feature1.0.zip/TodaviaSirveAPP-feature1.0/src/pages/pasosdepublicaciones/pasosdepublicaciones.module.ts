import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PasosdepublicacionesPage } from './pasosdepublicaciones';

@NgModule({
  declarations: [
    PasosdepublicacionesPage,
  ],
  imports: [
    IonicPageModule.forChild(PasosdepublicacionesPage),
  ],
})
export class PasosdepublicacionesPageModule {}
