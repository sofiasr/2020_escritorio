export interface Paso{
    id
    numero
    descripcion
    imagen
    idPublicacion
}