export interface Publicacion{
    id
    titulo
    subtitulo
    descripcion
    fechaSubida
    imagenPortada
    idUsuario
}