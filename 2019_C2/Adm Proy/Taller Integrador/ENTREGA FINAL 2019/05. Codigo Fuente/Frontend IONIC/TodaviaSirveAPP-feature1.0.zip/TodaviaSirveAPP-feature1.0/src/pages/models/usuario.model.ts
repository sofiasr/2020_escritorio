export interface Usuario{
    id
    nombre
    apellido
    email
    username
    pass
    imagen
}