﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoAPI.Models.ViewModel
{
    public class ComentarioUsuario
    {
        public string imagen { get; set; }
        public string comentario { get; set; }
    }
}